//
//  ContentView.swift
//  ZorroSignWidget
//
//  Created by Randimal Geeganage on 2021-06-19.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

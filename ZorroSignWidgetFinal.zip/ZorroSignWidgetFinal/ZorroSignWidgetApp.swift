//
//  ZorroSignWidgetApp.swift
//  ZorroSignWidget
//
//  Created by Randimal Geeganage on 2021-06-19.
//

import SwiftUI

@main
struct ZorroSignWidgetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
